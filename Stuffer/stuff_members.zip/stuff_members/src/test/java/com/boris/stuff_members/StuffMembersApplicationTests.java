package com.boris.stuff_members;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StuffMembersApplicationTests {

	@Test
	void contextLoads() {
	}

}
